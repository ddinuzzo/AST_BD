from pyspark import SparkContext

class Film:
    def __init__(self, film_row):
        values = film_row.split('|')
        self.id = values[0]
        self.title = values[1]
        self.pub_date = values[2]
        self.uri = values[4]
    def __str__(self):
        return 'ID   : ' + self.id + '\n' + \
               'TITLE: ' + self.title + '\n' + \
               'DATE : ' + self.pub_date + '\n' + \
               'URL  : ' + self.uri

def main():
    SEARCH_TEXT = 'batman'
    sc = SparkContext( appName = "TerzoEsercizio" )
    films = sc.textFile('/user/cloudera/datasets/movies', minPartitions=3,) \
            .filter(lambda line: SEARCH_TEXT in line.lower())
    films.persist()
    films_count = films.count()
    films_data = films.collect()
    print("Il numero di films che presentano la parola <" + SEARCH_TEXT + "> sono (" + str(films_count) + "):")
    for line in films_data:
	print('----------------------------')
        print(Film(line))
    print('----------------------------')

if __name__ == '__main__':
    main()
