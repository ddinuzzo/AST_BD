from pyspark import SparkContext
from pyspark.sql import SQLContext

def main():
    sc = SparkContext( appName = "EsercizioSQL" )
    sqlContext = SQLContext(sc)
    query = """
            SHOW TABLES
            """
    result = sqlContext.sql(query).show()
    
if __name__ == '__main__':
    main()
