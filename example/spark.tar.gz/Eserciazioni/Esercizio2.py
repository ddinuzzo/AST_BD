from pyspark import SparkContext

def main():
    SEARCH_TEXT = 'batman'
    sc = SparkContext( appName = "SecondoEsercizio" )
    num_film = sc.textFile('/user/cloudera/datasets/movies') \
            .filter(lambda line: SEARCH_TEXT in line.lower()) \
            .count()
    print("Il numero di films che presentano la parola " + SEARCH_TEXT + " e': " + str(num_film))

if __name__ == '__main__':
    main()
