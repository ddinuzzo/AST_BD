from pyspark import SparkContext

def main():
    sc = SparkContext( appName = "PrimoEsercizio" )
    num_record = sc.textFile('/user/cloudera/datasets/movies').count()
    print("Il numero di films presenti nella lista e': " + str(num_record))

if __name__ == '__main__':
    main()
