from pyspark import SparkContext

def get_users():
    return [(1, 'Danilo', 'Di Nuzzo'),
            (2, 'Francesco', 'Esposito'),
            (3, 'Teresa', 'Esposito'),
            (4, 'Federica', 'Raviele'),
            (5, 'Umberto', 'Gioradano')]

def get_emails():
    return [('danilo.dinuzzo@r-dev.it', 1),
            ('francesco.esposito@accenture.it', 2),
            ('umberto.giordano@ntt-data.it', 5)]

def main():
    sc = SparkContext( appName = "EsercizioJoin" )
    # RDD utenti
    users = sc.parallelize( get_users() )
    # RDD emails
    emails = sc.parallelize( get_emails() )
    # Con keyBy creo un RDD chiave/valore dove la chiave
    # e' il valore determinato dalla funzione lambda (x[1])
    results = emails.keyBy(lambda x: x[1]) \
                    .rightOuterJoin(users).collect()
    # Esiste anche la leftOuterJoin ma in questo caso
    # avrebbe restituito lo stesso risultato di una inner
    for result in results:
        print(result)

if __name__ == '__main__':
    main()
