from pyspark import SparkContext

def reduce_func(x, y):
    print('x & y: ', x, y)
    return x + y

def main():
    sc = SparkContext( appName = "TestReduce" )
    numbers = sc.parallelize([1,2,3,4,5,6,7,8,9])
    totale = numbers.reduce(reduce_func)

    print('TOTALE: ', totale)

if __name__ == '__main__':
    main()
